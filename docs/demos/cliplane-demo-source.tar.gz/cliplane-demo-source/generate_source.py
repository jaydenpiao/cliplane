"""Original deterministic pseudo-3D driving animation; no downloaded assets."""
from pathlib import Path
import argparse, math, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parent
W,H=1280,720
F=470
HORIZON=255
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
fonts={size:ImageFont.truetype(FONT,size) for size in (12,14,16,18,20,22,24,28,32,46,64)}
bold={size:ImageFont.truetype(BOLD,size) for size in (16,18,20,22,24,28,32,46,64)}
rng=np.random.default_rng(7421)
yy=np.linspace(0,1,H)[:,None,None]
top=np.array([9,13,28])[None,None,:]
bottom=np.array([26,24,48])[None,None,:]
gradient=np.repeat((top*(1-yy)+bottom*yy).astype(np.uint8),W,axis=1)
BASE=Image.fromarray(gradient,'RGB')
d=ImageDraw.Draw(BASE)
for i in range(70):
    x=int(rng.integers(10,W-10));y=int(rng.integers(8,238))
    d.ellipse((x,y,x+1,y+1),fill=(76,107,135))
# A broad soft moon/halo, all procedural shapes.
for radius in range(95,42,-1):
    a=(95-radius)/53
    color=tuple(int(v) for v in (13+13*a,28+28*a,45+30*a))
    d.ellipse((945-radius,148-radius,945+radius,148+radius),fill=color)
d.ellipse((905,108,985,188),fill=(114,157,175))
d.ellipse((912,112,987,183),fill=(90,132,153))

def center(z):return 1150*math.sin(z/5100)+560*math.sin(z/8700)

def project(z,x,t,height=0):
    cam=t*2050
    sway=12*math.sin(t*.7)
    px=W/2+(center(cam+z)-center(cam)+x)*F/z-sway
    py=HORIZON+(1060-height)*F/z+2*math.sin(t*3.5)
    return px,py

def quad(d,points,color):d.polygon([(round(x),round(y)) for x,y in points],fill=color)

def glow_line(d,points,color,width=2):
    for width_,factor in ((width+8,.12),(width+3,.25),(width,.9)):
        d.line(points,fill=tuple(int(v*factor) for v in color),width=width_,joint='curve')

def car(d,cx,cy,size,color,phase=0,player=False):
    # Original rear-facing low-poly coupe; size is its projected half-width.
    s=size/100
    def P(x,y):return (cx+x*s,cy+y*s)
    d.ellipse((cx-111*s,cy+54*s,cx+111*s,cy+84*s),fill=(4,7,16))
    quad(d,[P(-92,3),P(-108,65),P(-81,70),P(-69,5)],(7,10,18))
    quad(d,[P(69,5),P(81,70),P(108,65),P(92,3)],(7,10,18))
    quad(d,[P(-82,-22),P(-52,-63),P(53,-63),P(83,-22),P(100,12),P(94,65),P(-94,65),P(-100,12)],color)
    quad(d,[P(-52,-60),P(53,-60),P(76,-21),P(-76,-21)],(21,42,59))
    quad(d,[P(-44,-52),P(45,-52),P(61,-28),P(-61,-28)],(38,72,87))
    d.line([P(-76,-18),P(76,-18)],fill=(116,153,161),width=max(1,int(2*s)))
    quad(d,[P(-99,14),P(99,14),P(94,65),P(-94,65)],tuple(max(0,int(v*.66)) for v in color))
    d.line([P(-88,22),P(-34,22)],fill=(255,107,89),width=max(1,int(6*s)))
    d.line([P(34,22),P(88,22)],fill=(255,107,89),width=max(1,int(6*s)))
    d.line([P(-84,32),P(-37,32)],fill=(164,49,67),width=max(1,int(2*s)))
    d.line([P(37,32),P(84,32)],fill=(164,49,67),width=max(1,int(2*s)))
    quad(d,[P(-94,52),P(94,52),P(86,66),P(-86,66)],(18,26,37))
    d.line([P(-75,68),P(75,68)],fill=(56,133,147),width=max(1,int(2*s)))
    if player:
        d.rounded_rectangle((*P(-21,38),*P(21,51)),radius=2,fill=(131,154,157))
        d.text(P(-14,38),'N/01',font=fonts[12],fill=(19,34,43))
        for sign in (-1,1):
            x,y=P(sign*65,73)
            d.ellipse((x-6*s,y-2*s,x+6*s,y+7*s),fill=(63,197,205))

def frame(t):
    im=BASE.copy();d=ImageDraw.Draw(im)
    cam=t*2050
    # Distant skyline and its mirrored, moving nearer structures.
    for i in range(28):
        x=(i*61+int(25*math.sin(t*.12)))%1460-100
        height=30+(i*47)%120
        d.rectangle((x,HORIZON-height,x+38,HORIZON+12),fill=(20,33,51))
        if i%3==0:d.line((x+8,HORIZON-height,x+8,HORIZON+5),fill=(36,67,86),width=2)
    d.rectangle((0,HORIZON+8,W,H),fill=(13,21,32))
    # Far-to-near city. Position is tied to world distance, never to frame count.
    for j in range(25,-1,-1):
        world=(math.floor(cam/600)+j)*600
        z=world-cam+700
        if z<660:continue
        for side in (-1,1):
            seed=(int(world/600)*37+(side+1)*13)%97
            worldx=side*(2350+(seed%5)*290)
            bw=550+(seed%3)*180
            height=1000+(seed%7)*210
            left,bottomy=project(z,worldx-bw/2,t)
            right,topy=project(z,worldx+bw/2,t,height)
            if right<-100 or left>W+100:continue
            color=(20+seed%11,32+seed%13,49+seed%18)
            d.rectangle((left,topy,right,bottomy),fill=color)
            depth=max(2,(right-left)*.15)
            quad(d,[(right,topy),(right+depth,topy+depth*.5),(right+depth,bottomy),(right,bottomy)],(14,25,40))
            if right-left>13:
                rows=min(10,max(2,int((bottomy-topy)/15)))
                cols=min(5,max(2,int((right-left)/12)))
                for row in range(rows):
                    for col in range(cols):
                        if (row*3+col+seed)%4==0:continue
                        wx=left+(col+.35)*(right-left)/cols
                        wy=topy+(row+.35)*(bottomy-topy)/rows
                        ww=max(1,(right-left)/cols*.23);wh=max(1,(bottomy-topy)/rows*.23)
                        d.rectangle((wx,wy,wx+ww,wy+wh),fill=(54,100,118) if seed%2 else (118,92,94))
    # Alternating road strips, lane paint, luminous rails.
    seg=120
    for idx in range(130,5,-1):
        z1=idx*seg-cam%seg+220;z2=z1+seg
        if z1<790:continue
        edge=[project(z1,-1650,t),project(z1,1650,t),project(z2,1650,t),project(z2,-1650,t)]
        stripe=int((cam+z1)/seg)%2
        quad(d,edge,(24,35,53) if stripe else (22,32,49))
        for side in (-1,1):
            x=side*1650
            quad(d,[project(z1,x-26,t),project(z1,x+26,t),project(z2,x+26,t),project(z2,x-26,t)],(65,171,180) if side<0 else (131,101,194))
        if int((cam+z1)/seg)%6<3:
            for lane in (-550,550):
                quad(d,[project(z1,lane-11,t),project(z1,lane+11,t),project(z2,lane+11,t),project(z2,lane-11,t)],(151,169,178))
    # Repeated checkpoint gantries travel from horizon to camera.
    for gate in range(3):
        z=(gate*7600-cam)%22800+800
        if z>16000:continue
        lx,base=project(z,-1810,t);rx,_=project(z,1810,t)
        _,top=project(z,0,t,2200)
        if top<0 or base>H+100:continue
        width=max(2,int(F*24/z))
        glow_line(d,[(lx,base),(lx,top+20),(lx+35,top),(rx-35,top),(rx,top+20),(rx,base)],(54,194,203),width)
    # Traffic creates readable motion and passing moments without copyrighted imagery.
    vehicles=[]
    for index in range(9):
        z=(index*1811+6500-t*(580+(index%3)*160))%16500+800
        lane=(-1,0,1)[index%3]*1040
        x,y=project(z,lane+70*math.sin(index+t*.3),t)
        vehicles.append((z,x,y,index))
    palette=[(132,66,97),(76,116,149),(154,122,72),(92,101,145)]
    for z,x,y,index in sorted(vehicles,reverse=True):
        size=F*230/z
        if 0<y<H+120:car(d,x,y-50*size/100,size,palette[index%4])
    # Soft speed streaks on the periphery only; road and controls remain readable.
    boost=math.exp(-((t-7.2)/1.0)**2)+math.exp(-((t-17.4)/1.0)**2)
    if boost>.12:
        for k in range(18):
            side=-1 if k%2 else 1
            phase=(t*3+k*.137)%1
            x=640+side*(180+phase*570);y=280+phase*410
            d.line((x,y,x+side*(15+phase*65),y+15+phase*35),fill=(35,78,95),width=2)
    # Player car leans into the route while its reflection follows the camera.
    px=640+45*math.sin(t*.75)+18*math.sin(t*1.8)
    py=577+2*math.sin(t*12)
    car(d,px,py,91,(69,118,135),t,True)
    # Minimal original HUD. Every frame identifies its synthetic provenance.
    d.rounded_rectangle((30,26,387,83),radius=9,fill=(12,23,36),outline=(38,62,80),width=1)
    d.ellipse((47,43,56,52),fill=(96,218,205))
    d.text((68,36),'NIGHTDRIFT / ORIGINAL DEMO',font=bold[18],fill=(215,233,234))
    d.text((69,61),'Procedural motion · no game footage',font=fonts[12],fill=(122,155,170))
    d.text((1120,36),f'{int(t)//60:02}:{int(t)%60:02}.{int(t*10)%10}',font=fonts[24],fill=(201,220,227))
    d.text((1114,66),'LIVE SIMULATION',font=fonts[12],fill=(110,150,166))
    d.rounded_rectangle((1082,576,1248,690),radius=13,fill=(10,22,35),outline=(38,63,80),width=1)
    speed=204+round(12*math.sin(t*.42)+14*boost)
    d.text((1100,586),str(speed),font=bold[64],fill=(216,238,237))
    d.text((1104,660),'DEMO KM/H',font=fonts[14],fill=(119,161,174))
    d.rounded_rectangle((31,561,197,690),radius=12,fill=(10,22,35),outline=(38,63,80),width=1)
    route=[(51+22*math.sin(k*.4+t*.1),672-k*5) for k in range(18)]
    d.line(route,fill=(49,83,101),width=7,joint='curve')
    d.line(route,fill=(100,191,184),width=2,joint='curve')
    d.ellipse((46,657,56,667),fill=(226,180,122))
    d.text((91,584),'SECTOR 03',font=fonts[12],fill=(126,162,176))
    d.text((91,608),'NORTH\nLOOP',font=bold[16],fill=(202,223,226))
    d.text((92,662),'AUTOPILOT',font=fonts[12],fill=(112,150,168))
    if boost>.45:
        d.rounded_rectangle((496,125,784,170),radius=9,fill=(16,45,54),outline=(53,116,126),width=1)
        d.text((524,137),'CLEAN PASS  +450',font=bold[20],fill=(119,226,205))
    return im

def audio(path,duration):
    sr=48000;t=np.arange(int(duration*sr),dtype=np.float64)/sr
    frequency=72+7*np.sin(t*.45)+4*np.sin(t*.13)
    phase=np.cumsum(frequency)*2*np.pi/sr
    engine=np.sin(phase)+.25*np.sin(phase*2)+.1*np.sin(phase*4)
    boost=np.exp(-((t-7.2)/.7)**2)+np.exp(-((t-17.4)/.8)**2)
    noise=np.random.default_rng(175).normal(0,1,len(t))
    noise=np.convolve(noise,np.ones(23)/23,mode='same')
    signal=engine*(.035+.12*boost)+noise*(.03+.10*boost)
    signal*=np.minimum(1,t*8)*np.minimum(1,(duration-t)*8)
    with wave.open(str(path),'wb') as wav:
        wav.setnchannels(1);wav.setsampwidth(2);wav.setframerate(sr)
        wav.writeframes((np.clip(signal,-.95,.95)*32767).astype('<i2').tobytes())

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--duration',type=float,default=24)
    parser.add_argument('--fps',type=int,default=30);parser.add_argument('--preview',action='store_true')
    args=parser.parse_args();ROOT.mkdir(exist_ok=True)
    for t in (1,7.2,17.4):frame(t).save(ROOT/f'source-preview-{t:g}.jpg',quality=92)
    if args.preview:return
    sound=ROOT/'original-engine.wav';audio(sound,args.duration)
    target=ROOT/'nightdrift-original-motion.mp4'
    cmd=['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(args.fps),'-i','pipe:0','-i',str(sound),'-t',str(args.duration),'-c:v','libx264','-preset','veryfast','-crf','20','-threads','2','-pix_fmt','yuv420p','-c:a','aac','-b:a','96k','-movflags','+faststart',str(target)]
    proc=subprocess.Popen(cmd,stdin=subprocess.PIPE)
    try:
        for index in range(round(args.duration*args.fps)):
            proc.stdin.write(frame(index/args.fps).tobytes())
        proc.stdin.close()
        if proc.wait()!=0:raise RuntimeError('FFmpeg encoding failed')
    finally:
        if proc.poll() is None:proc.kill();proc.wait()
    print(target)

if __name__=='__main__':main()
