"""Make a factual social cut from real Playwright footage; no retiming."""
import json
import os
from datetime import datetime
from pathlib import Path
import subprocess

ROOT=Path(os.environ.get('DEMO_DIR', str(Path(os.environ.get('CLIPLANE_ROOT', Path.cwd()))/'work'/'demo-capture'))).resolve()
for subdir in ('assets','tmp'):
    (ROOT/subdir).mkdir(parents=True,exist_ok=True)
FFMPEG=os.environ.get('FFMPEG_BIN','ffmpeg')
FFPROBE=os.environ.get('FFPROBE_BIN','ffprobe')
RAW=ROOT/'cliplane-workflow-raw.webm'
FONT=os.environ.get('DEMO_FONT','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
BOLD=os.environ.get('DEMO_FONT_BOLD','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf')
BG='0x142823'

def run(args):
    subprocess.run(args,check=True,stdout=subprocess.DEVNULL)

def text(name,value):
    path=ROOT/'assets'/f'{name}.txt';path.write_text(value)
    return str(path)

def draw(path,size,x,y,bold=False,color='white'):
    return f"drawtext=fontfile='{BOLD if bold else FONT}':textfile='{path}':expansion=none:fontcolor={color}:fontsize={size}:x={x}:y={y}"

def encode(inputs,vf,duration,target):
    args=[FFMPEG,'-hide_banner','-loglevel','error','-y',*inputs,'-t',str(round(duration,3)),'-an','-vf',vf+',setsar=1','-c:v','libx264','-preset','veryfast','-crf','18','-threads','2','-pix_fmt','yuv420p','-r','30','-video_track_timescale','15360','-movflags','+faststart',str(target)]
    run(args)
    commands.append(args)

def card(name,title,subtitle,duration,screenshot):
    target=ROOT/'tmp'/f'{len(segments):02}-{name}.mp4'
    titlefile=text(name+'-title',title)
    subfile=text(name+'-subtitle',subtitle)
    vf=','.join(['scale=1920:1080:force_original_aspect_ratio=increase','crop=1920:1080','gblur=sigma=28','drawbox=x=0:y=0:w=iw:h=ih:color=0x142823@0.86:t=fill','drawbox=x=130:y=286:w=105:h=8:color=0xea9b7f:t=fill',draw(titlefile,94,130,350,True),draw(subfile,42,136,495),draw(disclosure,25,136,970),f'fade=t=in:st=0:d=0.15',f'fade=t=out:st={duration-.15}:d=0.15','fps=30','format=yuv420p'])
    encode(['-loop','1','-i',str(screenshot)],vf,duration,target)
    segments.append(target);edits.append({'kind':'title-card','name':name,'duration':duration,'title':title,'subtitle':subtitle})

def screen(name,start,end,label):
    duration=end-start
    target=ROOT/'tmp'/f'{len(segments):02}-{name}.mp4'
    labelpath=text(name+'-label',label)
    vf=','.join(['fps=30','scale=1600:1000:flags=lanczos',f'pad=1920:1080:160:0:color={BG}',f'drawbox=x=0:y=1000:w=1920:h=80:color={BG}:t=fill',draw(labelpath,31,55,1023,True),draw(disclosure,19,1290,1030),'format=yuv420p'])
    encode(['-ss',str(round(start,3)),'-i',str(RAW)],vf,duration,target)
    segments.append(target);edits.append({'kind':'actual-browser','name':name,'rawStart':round(start,3),'rawEnd':round(end,3),'duration':round(duration,3),'label':label,'speed':1})

metadata=json.loads(subprocess.check_output([FFPROBE,'-v','error','-show_format','-show_streams','-of','json',str(RAW)]))
creation=datetime.fromisoformat(metadata['format']['tags']['creation_time'].replace('Z','+00:00'))
timings=json.loads((ROOT/'action-timings.json').read_text())
T={e['name']:(datetime.fromisoformat(e['wall'].replace('Z','+00:00'))-creation).total_seconds() for e in timings['events']}
commands=[];segments=[];edits=[]
# Offline resume needs only the released raw video, export, and timing JSON.
# Reconstruct title-card screenshots from the raw take when PNGs are absent.
(ROOT/'screenshots').mkdir(parents=True,exist_ok=True)
for name,stamp in [('studio-overview.png',T['dashboard-ready']-.2),('rendered-output-review.png',T['final-screenshot']-.2)]:
    screenshot=ROOT/'screenshots'/name
    if not screenshot.exists():
        args=[FFMPEG,'-hide_banner','-loglevel','error','-y','-ss',str(max(0,stamp)),'-i',str(RAW),'-frames:v','1',str(screenshot)]
        run(args);commands.append(args)
disclosure=text('disclosure','Synthetic footage · Processing waits cut')
card('intro','Cliplane.','From recording to reviewed clip.',2.4,ROOT/'screenshots'/'studio-overview.png')
screen('studio',T['dashboard-ready']-1.3,T['dashboard-ready']+.7,'A creator-controlled clipping studio')
screen('upload-file',T['upload-dialog']+.1,T['upload-dialog']+2.4,'01 / Bring in an authorized recording')
screen('upload-attest',T['upload-form-complete']-2.7,T['upload-submitted']+.5,'01 / Add context. Confirm permission.')
screen('candidates',T['candidates-ready']+.1,T['editor-open']+.25,'02 / Real candidates from audio + scene signals')
screen('trim',T['editor-open']+1.0,T['trim-and-layout-set']+.1,'03 / Trim to seven seconds. Choose a composition.')
screen('caption',T['trim-and-layout-set']+.15,T['caption-and-mute-set']+.4,'03 / Add a caption. Mute the audio.')
screen('rights',T['caption-and-mute-set']+3.1,T['caption-and-mute-set']+5.6,'04 / Review game, music and content rights')
screen('rights-evidence',T['rights-reviewed']-1.8,T['rights-reviewed']+.8,'04 / Keep the authorization with the edit')
screen('approve',T['rights-reviewed']+1.0,T['render-requested']+.8,'05 / Approve this revision. Render locally.')
screen('preview',T['render-ready']+.1,T['rendered-preview-playing']+3.5,'06 / Watch the actual rendered output')
screen('download',T['final-screenshot']-.2,T['download-saved']+.6,'06 / Download the finished MP4')

target=ROOT/'tmp'/f'{len(segments):02}-actual-export.mp4'
exporttitle=text('export-title','The actual export.')
exportdetails=text('export-details','7 seconds · 720 × 1280\nH.264 MP4\nCaption burned in\nAll audio muted')
exportvf=','.join(['scale=562:1000:flags=lanczos',f'pad=1920:1080:1180:40:color={BG}',draw(exporttitle,65,130,250,True),draw(exportdetails,35,135,380),draw(disclosure,25,135,975),'format=yuv420p'])
encode(['-ss','1.2','-i',str(ROOT/'cliplane-rendered-clip.mp4')],exportvf,3.5,target)
segments.append(target);edits.append({'kind':'actual-downloaded-export','source':'cliplane-rendered-clip.mp4','sourceStart':1.2,'duration':3.5})
card('end','Your final say. Every time.','Built in public · Real local workflow',2.5,ROOT/'screenshots'/'rendered-output-review.png')

manifest=ROOT/'tmp'/'concat.txt'
manifest.write_text(''.join(f"file '{p}'\n" for p in segments))
concat=[FFMPEG,'-hide_banner','-loglevel','error','-y','-f','concat','-safe','0','-i',str(manifest),'-an','-vf','fps=30,setsar=1,format=yuv420p','-c:v','libx264','-preset','veryfast','-crf','16','-threads','2','-pix_fmt','yuv420p','-r','30','-movflags','+faststart',str(ROOT/'cliplane-demo-edited.mp4')]
run(concat);commands.append(concat)
(ROOT/'edit-decision-list.json').write_text(json.dumps({'rawCreationTime':creation.isoformat(),'output':'cliplane-demo-edited.mp4','resolution':[1920,1080],'fps':30,'speedChanges':False,'audio':'silent','edits':edits},indent=2))
(ROOT/'ffmpeg-commands.json').write_text(json.dumps(commands,indent=2))
print(json.dumps({'output':str(ROOT/'cliplane-demo-edited.mp4'),'nominalDuration':sum(e['duration'] for e in edits),'segments':len(segments)},indent=2))
