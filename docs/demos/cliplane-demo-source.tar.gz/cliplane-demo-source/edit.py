#!/usr/bin/env python3
"""Cut a real screen recording, with restrained moving crops and no retiming."""
import argparse
from datetime import datetime
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


def number(value):
    result = float(value)
    if not math.isfinite(result):
        raise ValueError("All times and camera settings must be finite")
    return result


def timestamp(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def probe(filename, binary):
    return json.loads(subprocess.check_output([
        binary, "-v", "error", "-show_entries",
        "format=duration:format_tags=creation_time:stream=codec_type,width,height,avg_frame_rate,pix_fmt,codec_name",
        "-of", "json", str(filename),
    ]))


def default_segments(export_duration):
    def at(event, offset=0):
        return {"event": event, "offset": offset}

    return [
        {"name": "source", "start": at("source-playing", .15), "duration": 3.0,
         "label": "Original motion recording", "focus": [.44, .47], "zoom": [1.02, 1.16]},
        {"name": "upload", "start": at("upload-dialog", .25), "duration": 2.1,
         "label": "Bring in a recording", "focus": [.52, .5], "zoom": [1, 1.10]},
        {"name": "permission", "start": at("upload-form-complete", -1.3),
         "end": at("upload-submitted", .3), "label": "Confirm permission",
         "focus": [.57, .69], "zoom": [1.10, 1.10]},
        {"name": "candidates", "start": at("candidate-visible", .15), "duration": 2.8,
         "label": "Choose a candidate", "focus": [.43, .48], "zoom": [1, 1.07]},
        {"name": "trim", "start": at("trim-and-layout-set", -4.3),
         "end": at("trim-and-layout-set", .15), "label": "Trim + compose",
         "focus": [.64, .60], "zoom": [1.04, 1.22]},
        {"name": "caption", "start": at("trim-and-layout-set", .2),
         "end": at("caption-and-mute-set", .3), "label": "Caption + audio",
         "focus": [.74, .61], "zoom": [1.16, 1.16]},
        {"name": "rights", "start": at("rights-reviewed", -2.8),
         "end": at("rights-reviewed", .4), "label": "Rights review",
         "focus": [.70, .53], "zoom": [1.10, 1.20]},
        {"name": "approve", "start": at("rights-reviewed", .8),
         "end": at("render-requested", .5), "label": "Approve this edit",
         "focus": [.75, .76], "zoom": [1.16, 1.16]},
        {"name": "preview", "start": at("final-preview-playing", .15), "duration": 3.6,
         "label": "Preview the render", "focus": [.42, .48], "zoom": [1.08, 1.18]},
        {"name": "download", "start": at("download-saved", -1.6), "duration": 1.8,
         "label": "Download the MP4", "focus": [.74, .75], "zoom": [1.12, 1.12]},
        {"name": "export", "source": "export", "start": 0,
         "duration": min(7, export_duration), "label": "Actual downloaded export",
         "zoom": [1, 1], "fit": "contain"},
    ]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dir", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--raw", default="raw.webm")
    parser.add_argument("--export", dest="export_file", default="export.mp4")
    parser.add_argument("--timings", default="action-timings.json")
    parser.add_argument("--plan", type=Path)
    parser.add_argument("--output", default="demo-edited.mp4")
    parser.add_argument("--dry-run", action="store_true", help="Print resolved cuts; do not encode or write files")
    args = parser.parse_args()
    root = args.dir.resolve()
    ffmpeg = os.environ.get("FFMPEG_BIN", "ffmpeg")
    ffprobe = os.environ.get("FFPROBE_BIN", "ffprobe")
    plan = json.loads(args.plan.read_text()) if args.plan else {}
    sources = {"raw": (root / args.raw).resolve(), "export": (root / args.export_file).resolve()}
    output = (root / args.output).resolve()
    if output in sources.values():
        raise ValueError("Output must differ from both input files")
    metadata = {name: probe(filename, ffprobe) for name, filename in sources.items()}
    durations = {name: number(data["format"]["duration"]) for name, data in metadata.items()}
    timings = json.loads((root / args.timings).read_text())
    tags = metadata["raw"]["format"].get("tags", {})
    creation_value = next((v for k, v in tags.items() if k.lower() == "creation_time"), None)
    creation = timestamp(creation_value) if creation_value else None
    events = {}
    offset = number(plan.get("timingOffset", 0))
    for event in timings["events"]:
        if "videoSeconds" in event:
            seconds = number(event["videoSeconds"])
        elif creation and event.get("wall"):
            seconds = (timestamp(event["wall"]) - creation).total_seconds()
        else:
            seconds = number(event["seconds"])
        events[event["name"]] = seconds + offset
    events.update({name: number(value) for name, value in plan.get("events", {}).items()})
    for target, fallback in [("candidate-visible", "candidates-ready"),
                             ("final-preview-playing", "rendered-preview-playing")]:
        if target not in events and fallback in events:
            events[target] = events[fallback]
    if not creation and not all("videoSeconds" in event for event in timings["events"]):
        print("Timing note: no raw creation_time; event.seconds is assumed to use raw t=0. "
              "Use --plan timingOffset/events if it does not.", file=sys.stderr)

    def resolve(value):
        if isinstance(value, str):
            return events[value]
        if isinstance(value, dict):
            return events[value["event"]] + number(value.get("offset", 0))
        return number(value)

    width, height = plan.get("size", [1600, 900])
    if not all(isinstance(v, int) and 320 <= v <= 3840 and v % 2 == 0 for v in (width, height)):
        raise ValueError("size must contain two even integers between 320 and 3840")
    fps = 30
    resolved = []
    specs = plan.get("segments") or default_segments(durations["export"])
    for index, spec in enumerate(specs):
        source = spec.get("source", "raw")
        if source not in sources:
            raise ValueError("Segments may use only raw or export video")
        start = max(0, resolve(spec["start"]))
        end = resolve(spec["end"]) if "end" in spec else start + number(spec["duration"])
        end = min(end, durations[source])
        first, last = round(start * fps), min(round(end * fps), math.floor(durations[source] * fps))
        if last - first < fps // 2:
            raise ValueError(f"Segment {index} is shorter than 0.5 s or outside its input; adjust --plan")
        focus = list(map(number, spec.get("focus", [.5, .5])))
        zoom = spec.get("zoom", [1, 1])
        zoom = [1, zoom] if isinstance(zoom, (int, float)) else list(map(number, zoom))
        if len(focus) != 2 or not all(0 <= v <= 1 for v in focus):
            raise ValueError("focus must be [x,y], normalized from 0 to 1")
        if len(zoom) != 2 or not all(1 <= v <= 1.4 for v in zoom):
            raise ValueError("zoom must be [start,end] between 1 and 1.4")
        fit = spec.get("fit", "contain")
        if fit not in ("contain", "cover"):
            raise ValueError("fit must be contain or cover")
        label = spec.get("label", "")
        if not isinstance(label, str) or len(label) > 70 or "\n" in label:
            raise ValueError("Use a single-line label of at most 70 characters")
        resolved.append({"name": spec.get("name", f"cut-{index}"), "source": source,
                         "start": first / fps, "end": last / fps, "frames": last - first,
                         "duration": (last - first) / fps, "focus": focus, "zoom": zoom,
                         "ease": max(.3, number(spec.get("ease", 1.2))), "fit": fit, "label": label})
    if not resolved or not any(s["source"] == "raw" for s in resolved) or resolved[-1]["source"] != "export":
        raise ValueError("Use real browser footage and finish with the downloaded export")
    nominal = sum(s["duration"] for s in resolved)
    if not 30 <= nominal <= 50:
        raise ValueError(f"Cuts total {nominal:.2f}s; adjust --plan to keep the cut between 30 and 50s")
    summary = {"size": [width, height], "fps": fps, "durationSeconds": nominal,
               "speedChanges": False, "audio": "silent", "segments": resolved}
    if args.dry_run:
        print(json.dumps(summary, indent=2))
        return

    font = Path(os.environ.get("DEMO_FONT", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"))
    if not font.is_file():
        raise ValueError("Set DEMO_FONT to an installed TTF font file")
    output.parent.mkdir(parents=True, exist_ok=True)
    commands = []
    with tempfile.TemporaryDirectory(prefix=".demo-edit-", dir=root) as temp:
        work = Path(temp)
        shutil.copyfile(font, work / "font.ttf")
        (work / "disclosure.txt").write_text("Synthetic motion demo · Waits cut", encoding="utf-8")

        def run(command):
            commands.append(command)
            subprocess.run(command, cwd=work, check=True, stdout=subprocess.DEVNULL)

        pieces = []
        for index, segment in enumerate(resolved):
            filename = f"segment-{index:02}.mp4"
            pieces.append(filename)
            (work / "label.txt").write_text(segment["label"], encoding="utf-8")
            z0, z1 = segment["zoom"]
            ease = min(segment["ease"], segment["duration"])
            # One output frame per input frame. Smoothstep changes the camera, never time.
            progress = f"min(1,on/{fps * ease:.6f})"
            smooth = f"(({progress})*({progress})*(3-2*({progress})))"
            zoom = f"{z0:.6f}+({z1-z0:.6f})*{smooth}"
            fx, fy = segment["focus"]
            crop_x = f"max(0,min(iw-iw/zoom,iw*{fx:.6f}-iw/zoom/2))"
            crop_y = f"max(0,min(ih-ih/zoom,ih*{fy:.6f}-ih/zoom/2))"
            if segment["fit"] == "contain":
                fit = (f"scale={width}:{height}:force_original_aspect_ratio=decrease,"
                       f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2:color=0x080c0e")
            else:
                fit = f"scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height}"
            # Supersampling makes the small digital camera move less prone to pixel steps.
            filters = ["setpts=PTS-STARTPTS", "fps=30", fit, "setsar=1",
                       f"scale={width*2}:{height*2}:flags=lanczos",
                       f"zoompan=z='{zoom}':x='{crop_x}':y='{crop_y}':d=1:s={width}x{height}:fps=30"]
            if segment["label"]:
                filters.append("drawtext=fontfile=font.ttf:textfile=label.txt:expansion=none:"
                               f"fontsize={round(width*.015)}:fontcolor=white:x=30:y=h-83:"
                               "box=1:boxcolor=black@0.44:boxborderw=9")
            filters += ["drawtext=fontfile=font.ttf:textfile=disclosure.txt:expansion=none:"
                        f"fontsize={round(width*.0105)}:fontcolor=white@0.8:x=30:y=h-34:"
                        "box=1:boxcolor=black@0.34:boxborderw=5", "scale=in_range=auto:out_range=tv", "format=yuv420p", "setparams=range=limited", "setsar=1"]
            run([ffmpeg, "-hide_banner", "-loglevel", "error", "-nostdin", "-y",
                 "-threads", "2", "-filter_threads", "1", "-ss", f"{segment['start']:.6f}",
                 "-i", str(sources[segment["source"]]), "-map", "0:v:0", "-an",
                 "-vf", ",".join(filters), "-frames:v", str(segment["frames"]),
                 "-map_metadata", "-1", "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
                 "-threads", "2", "-pix_fmt", "yuv420p", "-color_range", "tv", "-video_track_timescale", "90000", filename])
        (work / "concat.txt").write_text("".join(f"file '{name}'\n" for name in pieces))
        run([ffmpeg, "-hide_banner", "-loglevel", "error", "-nostdin", "-y", "-f", "concat",
             "-safe", "0", "-i", "concat.txt", "-map", "0:v:0", "-an", "-c:v", "copy",
             "-map_metadata", "-1", "-video_track_timescale", "90000", "-movflags", "+faststart", "finished.mp4"])
        final = probe(work / "finished.mp4", ffprobe)
        (root / "encode-debug.json").write_text(json.dumps({"actual": final, "expected": summary}, indent=2))
        shutil.copyfile(work / "finished.mp4", root / "encode-review.mp4")
        video = [s for s in final["streams"] if s["codec_type"] == "video"]
        if (len(video) != 1 or video[0]["codec_name"] != "h264" or video[0]["pix_fmt"] != "yuv420p"
                or [video[0]["width"], video[0]["height"]] != [width, height]
                or abs(number(final["format"]["duration"]) - nominal) > .10
                or any(s["codec_type"] == "audio" for s in final["streams"])):
            raise ValueError("Encoded output failed format/duration checks")
        run([ffmpeg, "-hide_banner", "-loglevel", "error", "-nostdin", "-i", "finished.mp4", "-f", "null", "-"])
        (work / "finished.mp4").replace(output)
    (root / "resolved-edit-plan.json").write_text(json.dumps(summary, indent=2))
    (root / "edit-commands.json").write_text(json.dumps(commands, indent=2))
    print(json.dumps({"output": str(output), "durationSeconds": number(final["format"]["duration"]),
                      "segments": len(resolved), "fullDecode": "passed"}, indent=2))


if __name__ == "__main__":
    main()
