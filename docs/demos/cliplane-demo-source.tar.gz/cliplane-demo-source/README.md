# Cliplane demo source bundle

Capture → edit → verify scripts for the real Cliplane demo. This bundle contains seven small text files: three scripts, the original action timings, edit decision list, FFmpeg command log, and this guide. Videos, screenshots, account records, browser state, and profiles are excluded.

## Resume without the app

For offline re-editing, copy the retained raw recording and actual exported clip from the capture workspace. If they are unavailable, capture a fresh take using the steps below. From the Cliplane clone, set an output directory and put these files there:

```text
cliplane-workflow-raw.webm
cliplane-rendered-clip.mp4
action-timings.json         # copy from this bundle; matches the retained raw take
```

Then run:

```sh
export DEMO_DIR="$PWD/work/demo-capture"
python3 /path/to/cliplane-demo-source/edit.py
python3 /path/to/cliplane-demo-source/verify.py
```

Editing reconstructs missing title-card screenshots from the raw recording, so no app session or recapture is required. The original cut is approximately 48 seconds at 1920 × 1080, 30 fps, H.264/yuv420p, silent, with fast-start metadata. Cuts remove waits and some form entry; playback speed remains unchanged. Visual reproduction is intended; encoder versions and reconstructed screenshots can change output bytes.

To verify already downloaded assets without editing, place the public edited MP4 in the same directory as the raw and exported clip, named `cliplane-demo-edited.mp4`, and run only `verify.py`.

## Capture a new take

Requirements: Linux, Node/project dependencies installed, Python 3.10+, system Chromium, FFmpeg/ffprobe with libx264/drawtext, and DejaVu Sans fonts. Start the seeded development app using the repository setup instructions. The default app URL is `http://localhost:3000`. Avoid running a Next build during capture.

Choose a **synthetic** source at least 19 seconds long. The sample studio seed creates 65-second original-art files at `data/<workspace>/<source>/original/master.bin`, beside `art.png`. Set that exact file explicitly; the script does not search or choose private media.

```sh
# Run from the Cliplane clone.
export CLIPLANE_ROOT="$PWD"
export DEMO_DIR="$PWD/work/demo-new-take"
export DEMO_SOURCE="/absolute/path/to/seeded/original/master.bin"
node /path/to/cliplane-demo-source/record.mjs
python3 /path/to/cliplane-demo-source/edit.py
python3 /path/to/cliplane-demo-source/verify.py
```

The capture signs into the seeded demo workspace before recording, uploads the supplied synthetic file, selects a candidate, trims 12–19 seconds, adds a caption, mutes audio, reviews rights, approves/renders, previews, and downloads the actual clip. A unique run label keeps new uploads separate from earlier takes. It writes new timing data and a minimal evidence summary without account identifiers or response bodies. It creates fresh temporary browser state and never reads an existing profile. No browser download or dependency installation occurs.

`DEMO_DIR` defaults to `<CLIPLANE_ROOT>/work/demo-capture`; `CLIPLANE_ROOT` defaults to the current directory. Optional settings: `APP_URL`, `DEMO_RUN_LABEL`, `CHROMIUM_PATH` (default `/usr/bin/chromium`), `FFMPEG_BIN` (absolute executable path for capture; default `/usr/bin/ffmpeg`), `FFPROBE_BIN`, `DEMO_FONT`, and `DEMO_FONT_BOLD`. Use output paths without apostrophes or colons because FFmpeg filter text uses quoted paths. The capture prepares its own system-FFmpeg symlink for Playwright. Existing app demo login must be enabled.

## Audit and checkpoint files

The included JSON files describe the original published take. `${DEMO_DIR}` in `ffmpeg-commands.json` is a portable placeholder; the runnable scripts generate commands with the actual configured path. A new capture overwrites its own `action-timings.json`; editing regenerates the EDL and FFmpeg log. Keep each take in a separate `DEMO_DIR` to resume it independently.

`verify.py` checks encoding, duration, dimensions, frame rate, silent audio, square pixels for the edited file, MP4 fast-start ordering, SHA-256 hashes, and full FFmpeg decoding. It also checks the minimal workflow summary when one exists. Capture selectors match the current Cliplane UI; inspect sampled frames after future UI changes.

No recordings or app tests were rerun when preparing this portable bundle. JavaScript/Python syntax, JSON syntax, archive membership, and secret/session-value exclusions were checked.

References: [Playwright videos](https://playwright.dev/docs/videos), [FFmpeg filters](https://ffmpeg.org/ffmpeg-filters.html).

License: Apache-2.0; see https://github.com/jaydenpiao/cliplane/blob/main/LICENSE .
