# Cliplane demo reproduction

Original source and scripts: Apache-2.0; repository LICENSE applies.
https://github.com/jaydenpiao/cliplane/blob/main/LICENSE

This bundle contains text only. Raw takes and downloaded exports are retained in the
capture workspace and are not hosted by this bundle. Recorded timings and resolved
cuts describe the published take; new captures generate their own timings.
Use a fresh DEMO_DIR for each take and run only one capture in it. Never capture
concurrently into the same directory; keep each raw recording with its own timings.

From a running Cliplane checkout with its local synthetic demo workspace, extract this
bundle outside the repository. The published take was captured at 1600 × 900 in the
America/Los_Angeles browser timezone on 2026-11-17 UTC; it is 39.767 seconds long.
Linux requirements: Node.js, installed project dependencies, Chromium, Python 3.10+,
FFmpeg/ffprobe with libx264, drawtext and zoompan, and DejaVu Sans. No social credentials,
browser profile or external account is used. The shared development demo must be enabled.

```sh
export CLIPLANE_ROOT="$PWD"
export DEMO_DIR=/absolute/path/to/cliplane-demo-source
export APP_URL=http://localhost:3001
export DEMO_SOURCE="$CLIPLANE_ROOT/packages/test-fixtures/nightdrift-original.mp4"
node "$DEMO_DIR/capture.mjs"
python "$DEMO_DIR/edit.py" --dir "$DEMO_DIR" --plan "$DEMO_DIR/plan.json"
python "$DEMO_DIR/verify.py" "$DEMO_SOURCE" "$DEMO_DIR/export.mp4" "$DEMO_DIR/demo-edited.mp4"
```

Set APP_URL, CHROMIUM_PATH, FFMPEG_BIN, FFPROBE_BIN and DEMO_FONT if needed.
The capture really uploads/analyzes the original source before opening the visible
take. It then selects the generated candidate, trims to 5–13s, applies vertical crop,
adds a caption, reviews rights, approves, renders and downloads. The final playback
uses the downloaded bytes. Import is not presented as a visible upload-form demo.

The edit uses actual interaction speed, cuts waits, applies small focal zooms and
ends on the full actual export. It creates no title cards and adds no music. Inspect
sampled frames and playback before sharing. Actual recorded footage is the evidence;
never fill missing actions with slides or pretend a stale timing file is a new take.

To regenerate the original 24s motion source optionally install Pillow and NumPy in a
separate virtualenv and run generate_source.py. It uses only procedural geometry,
generated audio and system DejaVu fonts. No downloaded game footage/assets are used.
The published take uses only packages/test-fixtures/nightdrift-original.mp4
(SHA-256 00252edb7bb38a20cf8b2f4504ce4afd54cdc04333d9e8a13496ad23d6e56a46).
Regeneration is not required. The verifier probes, fully decodes and hashes each input
and reports MP4 fast-start status. Inspect sampled frames before sharing.
