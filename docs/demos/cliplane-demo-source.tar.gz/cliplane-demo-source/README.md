# Cliplane demo reproduction

Original source and scripts: Apache-2.0; repository LICENSE applies.
https://github.com/jaydenpiao/cliplane/blob/main/LICENSE

This bundle contains text only. Raw takes and downloaded exports are retained in the
capture workspace and are not hosted by this bundle. Recorded timings and resolved
cuts describe the published take; new captures generate their own timings.

From a running, seeded Cliplane checkout, extract this bundle outside the repository.
Linux requirements: Node.js, installed project dependencies, Chromium, Python 3.10+,
FFmpeg/ffprobe with libx264, drawtext and zoompan, and DejaVu Sans. No social credentials,
browser profile or external account is used. The shared development demo must be enabled.

```sh
export CLIPLANE_ROOT="$PWD"
export DEMO_DIR=/absolute/path/to/cliplane-demo-source
export DEMO_SOURCE="$CLIPLANE_ROOT/packages/test-fixtures/nightdrift-original.mp4"
node "$DEMO_DIR/capture.mjs"
python "$DEMO_DIR/edit.py" --dir "$DEMO_DIR" --plan "$DEMO_DIR/plan.json"
python "$DEMO_DIR/verify.py" "$DEMO_DIR/demo-edited.mp4" "$DEMO_DIR/export.mp4"
```

Set APP_URL, CHROMIUM_PATH, FFMPEG_BIN, FFPROBE_BIN and DEMO_FONT if needed.
The capture really uploads/analyzes the original source before opening the visible
take. It then selects the generated candidate, trims to 5–13s, applies vertical crop,
adds a caption, reviews rights, approves, renders and downloads. The final playback
uses the downloaded bytes. Import is not presented as a visible upload-form demo.

The edit uses actual interaction speed, cuts waits, applies small focal zooms and
ends on the full actual export. It creates no title cards and adds no music. Inspect
sampled frames and playback before sharing. Actual recorded footage is the evidence;
never fill missing actions with slides or pretend a stale timing file is a new take.

To regenerate the original 24s motion source optionally install Pillow and NumPy in a
separate virtualenv and run generate_source.py. It uses only procedural geometry,
generated audio and system DejaVu fonts. No downloaded game footage/assets are used.
The default demo uses the checked-in fixture, so regeneration is not required.
