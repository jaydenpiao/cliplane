# Reproduce the Cliplane workbench demo

Scripts and original procedural source: Apache-2.0; repository LICENSE applies.
https://github.com/jaydenpiao/cliplane/blob/main/LICENSE

This bundle contains nine allowlisted text files, with no recordings, credentials,
cookies or account state. Each run creates a fresh isolated synthetic account and
really uploads/analyzes packages/test-fixtures/nightdrift-original.mp4 before the
visible take. Raw video, downloaded output and account state are not hosted here.
The source is original procedural geometry and generated sound, not gameplay.

Use a running local checkout with its normal database/API/web services and installed
project dependencies. Requirements: Node.js, system Chromium, Python, FFmpeg/ffprobe
with libx264/drawtext/zoompan, and DejaVu Sans. No external account or paid tool is used.
Run from the repository root with a fresh directory for each capture:

```sh
export CLIPLANE_ROOT="$PWD"
export DEMO_DIR=/absolute/path/to/a/new-take
export APP_URL=http://localhost:3000
node /path/to/this/bundle/capture.mjs
python /path/to/this/bundle/edit.py --dir "$DEMO_DIR" --plan /path/to/this/bundle/plan.json
python /path/to/this/bundle/verify.py "$CLIPLANE_ROOT/packages/test-fixtures/nightdrift-original.mp4" "$DEMO_DIR/export.mp4" "$DEMO_DIR/demo-edited.mp4"
```

Set CHROMIUM_PATH, DEMO_SOURCE or DEMO_FONT if needed. Capture at 1600×900, light mode,
en-US and America/Los_Angeles. Do not build Next while its running server is in use.
Never capture concurrently into the same directory or modify another take's inputs.

The actual flow plays the live composition, seeks decoded source frames, trims to
5–13s, applies portrait crop and captions, saves, reviews independent rights, approves
the exact edit/rights revisions, renders and downloads. The edit opens with a short
excerpt of that downloaded result and ends with its full eight seconds. Interaction
speed is unchanged; waits are cut and disclosed. There are no title cards or music.
Inspect saved frames and actual final-file playback before sharing.

Recorded timings/resolved cuts and sanitized workflow evidence describe the published
take. A new capture generates new timings; never reuse old times as a new recording.
The optional generate_source.py requires Pillow/NumPy and recreates original geometry;
regeneration is unnecessary because the checked-in 24s source is used directly.
Its SHA-256 is 00252edb7bb38a20cf8b2f4504ce4afd54cdc04333d9e8a13496ad23d6e56a46.
