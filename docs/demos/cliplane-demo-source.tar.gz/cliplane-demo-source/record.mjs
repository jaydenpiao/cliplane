import { copyFile, mkdir, readFile, symlink, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

// Run from a Cliplane clone, or set CLIPLANE_ROOT explicitly.
const projectRoot=path.resolve(process.env.CLIPLANE_ROOT || process.cwd());
const root=path.resolve(process.env.DEMO_DIR || path.join(projectRoot,'work','demo-capture'));
const appUrl=(process.env.APP_URL || 'http://localhost:3000').replace(/\/$/,'');
if(!process.env.DEMO_SOURCE) throw new Error('Set DEMO_SOURCE to an authorized synthetic MP4 of at least 19 seconds.');
for(const dir of ['raw','screenshots','tmp','assets','playwright-runtime']) await mkdir(path.join(root,dir),{recursive:true});
await copyFile(path.resolve(process.env.DEMO_SOURCE),path.join(root,'assets','sunset-sprint-original-art.mp4'));
process.env.PLAYWRIGHT_LEGACY_SCREENSHOT ??= '1';
process.env.PLAYWRIGHT_BROWSERS_PATH=path.join(root,'playwright-runtime');
process.env.TMPDIR ??= path.join(root,'tmp');
const registry=JSON.parse(await readFile(path.join(projectRoot,'node_modules','playwright-core','browsers.json'),'utf8'));
const revision=registry.browsers.find(item=>item.name==='ffmpeg').revision;
const runtime=path.join(process.env.PLAYWRIGHT_BROWSERS_PATH,`ffmpeg-${revision}`);
await mkdir(runtime,{recursive:true});
try { await symlink(process.env.FFMPEG_BIN || '/usr/bin/ffmpeg',path.join(runtime,'ffmpeg-linux')); }
catch(error) { if(error.code!=='EEXIST') throw error; }
const { chromium, expect }=await import(pathToFileURL(path.join(projectRoot,'node_modules','@playwright','test','index.mjs')).href);
const runLabel=process.env.DEMO_RUN_LABEL || Date.now().toString(36);
const recordingTitle=`Sunset sprint · demo ${runLabel}`;
const demoGame=`Build-in-public demo ${runLabel}`;
const events=[];
const responses=[];
const errors=[];
const started=Date.now();
const mark=(name,extra={})=>{ const event={name,wall:new Date().toISOString(),seconds:(Date.now()-started)/1000,...extra};events.push(event);console.log(JSON.stringify(event)); };
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH || '/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage'],downloadsPath:`${root}/tmp`});
const context=await browser.newContext({viewport:{width:1440,height:900},recordVideo:{dir:`${root}/raw`,size:{width:1440,height:900},fps:30,showActions:{duration:300,cursor:'pointer',style:{title:'display:none',highlight:'outline:2px solid #d7957e;outline-offset:3px;border-radius:5px;'}}},acceptDownloads:true,locale:'en-US',colorScheme:'light',reducedMotion:'no-preference'});
const auth=await context.request.post(`${appUrl}/api/auth/demo`,{data:{}}).catch(async error=>{await context.close();await browser.close();throw error;});
if(!auth.ok()) {await context.close();await browser.close();throw new Error(`Sample login failed: ${auth.status()}`);}
mark('authenticated-demo-workspace');
const page=await context.newPage();
page.on('pageerror',e=>errors.push(String(e)));
page.on('response',async response=>{
 const request=response.request();
 if(!response.url().includes('/api/'))return;
 if(request.method()!=='GET'){
   responses.push({wall:new Date().toISOString(),path:new URL(response.url()).pathname.replace(/[0-9a-f]{8}-[0-9a-f-]{27,}/gi,':id'),method:request.method(),status:response.status()});
 }
});
const pause=ms=>page.waitForTimeout(ms);
async function click(locator){await locator.scrollIntoViewIfNeeded();await locator.hover();await pause(220);await locator.click();await pause(320);}
async function fill(locator,text){await locator.scrollIntoViewIfNeeded();await locator.click();if(await locator.getAttribute('type')==='number'){await locator.fill(text);}else{await locator.fill('');await locator.pressSequentially(text,{delay:24});}await pause(180);}
let video;
try{
 mark('navigate');
 await page.goto(`${appUrl}/`,{waitUntil:'domcontentloaded'});
 await expect(page.getByRole('heading',{name:'Your next great moment is already in there.'})).toBeVisible();
 await expect(page.locator('.moment-card').first()).toBeVisible();
 await pause(1200);
 await page.screenshot({path:`${root}/screenshots/studio-overview.png`});
 mark('dashboard-ready');

 await click(page.getByRole('button',{name:'Upload recording',exact:true}));
 mark('upload-dialog');
 await pause(800);
 await page.locator('input[type="file"]').setInputFiles(`${root}/assets/sunset-sprint-original-art.mp4`);
 await pause(650);
 await fill(page.getByLabel('Recording title'),recordingTitle);
 await fill(page.getByLabel('Creator',{exact:true}),'Cliplane demo');
 await fill(page.getByLabel('Game',{exact:true}),demoGame);
 await fill(page.getByLabel('Authorization basis'),'Original synthetic artwork and generated test tone. Created for this demo.');
 await page.getByLabel('I own or am authorized').check();
 await pause(350);
 await page.getByLabel('The creator authorizes').check();
 await pause(900);
 mark('upload-form-complete');
 await click(page.getByRole('button',{name:'Find my moments'}));
 mark('upload-submitted');
 await expect(page.getByRole('dialog')).toHaveCount(0,{timeout:60000});
 await fill(page.getByLabel('Search moments'),demoGame);
 await expect(page.locator('.moment-card').first()).toBeVisible({timeout:90000});
 mark('candidates-ready');
 await pause(1500);
 await click(page.locator('.moment-image').first());
 await expect(page.getByRole('dialog')).toBeVisible();
 await expect.poll(()=>page.locator('video').evaluate(video=>video.readyState),{timeout:30000}).toBeGreaterThanOrEqual(2);
 mark('editor-open');
 await pause(800);
 await fill(page.getByLabel('Start (seconds)'),'12');
 await fill(page.getByLabel('End (seconds)'),'19');
 await fill(page.getByLabel('Clip title'),'A little room for the next story');
 await click(page.getByRole('button',{name:'Full frame'}));
 mark('trim-and-layout-set');
 await click(page.getByRole('button',{name:'Add cue'}));
 await fill(page.getByLabel('Caption 1',{exact:true}),'One recording. Your next story.');
 await page.getByLabel('Mute all audio').check();
 mark('caption-and-mute-set');
 await pause(900);
 await click(page.getByRole('button',{name:'Rights & review'}));
 await pause(700);
 await page.getByLabel('Game / underlying content rights').selectOption('authorized');
 await pause(400);
 await page.getByLabel('Music rights').selectOption('removed');
 await pause(400);
 await page.getByLabel('Spoiler risk').selectOption('low');
 await fill(page.getByLabel('Rights evidence / authorization basis'),'Original synthetic artwork. No game footage, music, or human voices.');
 await fill(page.getByLabel('Review or rejection note'),'Reviewed this exact edit for the original-art demo.');
 mark('rights-reviewed');
 await pause(1400);
 await click(page.getByRole('button',{name:'Approve & render',exact:true}));
 mark('render-requested');
 const download=page.getByRole('link',{name:'Download',exact:true});
 await expect(download).toBeVisible({timeout:90000});
 mark('render-ready');
 await pause(750);
 await click(page.getByRole('button',{name:'Watch rendered output'}));
 await expect.poll(()=>page.locator('video').evaluate(video=>video.readyState),{timeout:30000}).toBeGreaterThanOrEqual(2);
 await page.locator('video').scrollIntoViewIfNeeded();
 await page.locator('video').evaluate(video=>{video.muted=true;return video.play();});
 mark('rendered-preview-playing');
 await pause(4200);
 await page.locator('video').evaluate(video=>video.pause());
 await page.screenshot({path:`${root}/screenshots/rendered-output-review.png`});
 mark('final-screenshot');
 const [file]=await Promise.all([page.waitForEvent('download'),click(download)]);
 if(await file.failure())throw new Error(await file.failure());
 await file.saveAs(`${root}/cliplane-rendered-clip.mp4`);
 mark('download-saved',{filename:'cliplane-rendered-clip.mp4'});
 await pause(1800);
 const candidates=await (await context.request.get(`${appUrl}/api/candidates`)).json();
 const sources=await (await context.request.get(`${appUrl}/api/sources`)).json();
 const created=sources.find(s=>s.title===recordingTitle && s.game===demoGame && s.creator==='Cliplane demo');
 const candidate=candidates.find(c=>c.source_id===created?.id && c.title==='A little room for the next story');
 await writeFile(`${root}/workflow-evidence.json`,JSON.stringify({recordedAt:new Date().toISOString(),viewport:{width:1440,height:900},sourceStatus:created?.status,candidateStatus:candidate?.status,editRevision:candidate?.edit_revision,editPlan:{startMs:candidate?.edit_plan?.startMs,endMs:candidate?.edit_plan?.endMs,muteAudio:candidate?.edit_plan?.muteAudio,caption:candidate?.edit_plan?.captions?.[0]?.text},mutations:responses,pageErrorCount:errors.length},null,2));
 mark('workflow-complete');
}catch(error){
 mark('workflow-error',{message:String(error)});
 await page.screenshot({path:`${root}/screenshots/error.png`}).catch(()=>{});
 throw error;
}finally{
 video=page.video();
 await context.close();
 if(video)await video.saveAs(`${root}/cliplane-workflow-raw.webm`);
 await browser.close();
 await writeFile(`${root}/action-timings.json`,JSON.stringify({startedAt:new Date(started).toISOString(),events},null,2));
}
