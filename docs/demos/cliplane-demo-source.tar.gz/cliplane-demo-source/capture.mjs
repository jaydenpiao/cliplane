/** Real original-media workflow in a fresh isolated account. No credentials recorded. */
import { randomUUID } from 'node:crypto';
import { mkdir, readFile, symlink, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root=path.resolve(process.env.DEMO_DIR || path.dirname(fileURLToPath(import.meta.url)));
const project=path.resolve(process.env.CLIPLANE_ROOT || process.cwd());
const app=(process.env.APP_URL || 'http://localhost:3000').replace(/\/$/,'');
const source=path.resolve(process.env.DEMO_SOURCE || path.join(project,'packages/test-fixtures/nightdrift-original.mp4'));
for(const sub of ['raw','tmp','screenshots','playwright-runtime'])await mkdir(path.join(root,sub),{recursive:true});
process.env.PLAYWRIGHT_BROWSERS_PATH=path.join(root,'playwright-runtime');
process.env.TMPDIR=path.join(root,'tmp');
const registry=JSON.parse(await readFile(path.join(project,'node_modules/playwright-core/browsers.json'),'utf8'));
const revision=registry.browsers.find(item=>item.name==='ffmpeg').revision;
const runtime=path.join(process.env.PLAYWRIGHT_BROWSERS_PATH,`ffmpeg-${revision}`);
await mkdir(runtime,{recursive:true});
try{await symlink('/usr/bin/ffmpeg',path.join(runtime,'ffmpeg-linux'));}catch(e){if(e.code!=='EEXIST')throw e;}
const {chromium,expect}=await import(pathToFileURL(path.join(project,'node_modules/@playwright/test/index.mjs')).href);
const events=[];const requests=[];const started=Date.now();
const mark=(name,extra={})=>{const e={name,wall:new Date().toISOString(),seconds:(Date.now()-started)/1000,...extra};events.push(e);console.log(JSON.stringify(e));};
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH || '/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage'],downloadsPath:path.join(root,'tmp')});
const context=await browser.newContext({viewport:{width:1600,height:900},recordVideo:{dir:path.join(root,'raw'),size:{width:1600,height:900},fps:30,showActions:{duration:220,cursor:'pointer',style:{title:'display:none',highlight:'outline:1px solid rgba(103,80,230,.6);outline-offset:3px;border-radius:5px;'}}},acceptDownloads:true,locale:'en-US',timezoneId:'America/Los_Angeles',colorScheme:'light'});
let page;let rawVideo;let selected;let uploaded;let finalState;
const headers={Origin:app};
async function json(response){if(!response.ok())throw new Error(`Request failed (${response.status()})`);return response.json();}
const pause=ms=>page.waitForTimeout(ms);
async function click(locator){await locator.scrollIntoViewIfNeeded();await locator.hover();await pause(140);await locator.click();await pause(220);}
async function fill(locator,text){await locator.scrollIntoViewIfNeeded();await locator.click();if(await locator.getAttribute('type')==='number')await locator.fill(text);else{await locator.fill('');await locator.pressSequentially(text,{delay:12});}await pause(120);}
async function seek(locator,seconds){const box=await locator.boundingBox();if(!box)throw new Error('Timeline not visible');const min=Number(await locator.getAttribute('min'));const max=Number(await locator.getAttribute('max'));await locator.click({position:{x:8+(seconds-min)/(max-min)*(box.width-16),y:box.height/2}});await pause(300);}
async function dragRange(locator,seconds){const box=await locator.boundingBox();if(!box)throw new Error('Trim handle not visible');const min=Number(await locator.getAttribute('min'));const max=Number(await locator.getAttribute('max'));const value=Number(await locator.inputValue());const x=v=>box.x+6+(v-min)/(max-min)*(box.width-12);await page.mouse.move(x(value),box.y+box.height/2);await page.mouse.down();await page.mouse.move(x(seconds),box.y+box.height/2,{steps:18});await page.mouse.up();await pause(300);}
try{
 // Setup stays outside the visible recording; password is ephemeral and never logged.
 await json(await context.request.post(`${app}/api/auth/register`,{headers,data:{email:`demo-${randomUUID()}@example.test`,password:randomUUID(),name:'Cliplane creator',workspace:'Nightdrift studio'}}));
 uploaded=await json(await context.request.post(`${app}/api/sources`,{headers,multipart:{metadata:JSON.stringify({title:'Nightdrift / the close pass',creator:'Cliplane demo',game:'Nightdrift · Original motion',platform:'local',capturedAt:new Date().toISOString(),authorizationBasis:'I created this original procedural motion and generated sound. No game footage or external assets.',attestation:true,voiceAuthorized:true,embargoed:false}),file:{name:'nightdrift-original.mp4',mimeType:'video/mp4',buffer:await readFile(source)}}}));
 requests.push({method:'POST',path:'/api/sources',status:201});mark('import-complete');
 let sourceState;
 for(let attempt=0;attempt<90;attempt++){sourceState=await json(await context.request.get(`${app}/api/sources/${uploaded.id}`));if(sourceState.status==='ready')break;if(sourceState.status==='failed')throw new Error('Source analysis failed');await new Promise(r=>setTimeout(r,1000));}
 if(sourceState.status!=='ready')throw new Error('Analysis did not finish');
 selected=(await json(await context.request.get(`${app}/api/candidates`))).find(c=>c.source_id===uploaded.id);
 if(!selected)throw new Error('Real analysis produced no candidate');mark('analysis-ready');
 page=await context.newPage();rawVideo=page.video();
 page.on('response',response=>{const req=response.request();if(response.url().includes('/api/')&&req.method()!=='GET')requests.push({method:req.method(),path:new URL(response.url()).pathname.replace(/[0-9a-f]{8}-[0-9a-f-]{27,}/gi,':id'),status:response.status()});});
 await page.goto(app,{waitUntil:'domcontentloaded'});
 await expect(page.getByRole('heading',{name:'Your studio',exact:true})).toBeVisible();
 const card=page.locator('.moment-card').filter({has:page.locator(`img[src="/api/candidates/${selected.id}/thumbnail"]`)});
 await expect(card).toBeVisible({timeout:20000});await page.evaluate(()=>document.fonts.ready);
 await expect.poll(()=>card.locator('img').evaluate(i=>i.complete&&i.naturalWidth>0)).toBe(true);
 mark('candidate-visible');await pause(900);await click(card.locator('.moment-image'));
 const editor=page.getByRole('dialog',{name:'Clip editor'});await expect(editor).toBeVisible();
 const sourceVideo=editor.getByLabel('Source video',{exact:true});
 await expect.poll(()=>sourceVideo.evaluate(v=>v.readyState),{timeout:20000}).toBeGreaterThanOrEqual(2);
 await expect.poll(()=>editor.getByTestId('filmstrip-frame').count(),{timeout:20000}).toBeGreaterThan(2);
 await click(editor.getByRole('button',{name:'Play selection',exact:true}));mark('source-playing');
 const sourceFrom=await sourceVideo.evaluate(v=>v.currentTime);await pause(2300);
 const sourceTo=await sourceVideo.evaluate(v=>v.currentTime);if(sourceTo-sourceFrom<1)throw new Error('Source playback did not advance');mark('source-playback-verified',{from:sourceFrom,to:sourceTo});
 await click(editor.getByRole('button',{name:'Seek to 7.5 seconds',exact:true}));mark('filmstrip-scrubbed');
 await dragRange(editor.getByRole('slider',{name:'Trim start',exact:true}),5);
 await fill(editor.getByLabel('Start (seconds)',{exact:true}),'5');
 await fill(editor.getByLabel('End (seconds)',{exact:true}),'13');
 await fill(editor.getByLabel('Clip title',{exact:true}),'That was a close one');
 await click(editor.getByRole('button',{name:'Vertical crop'}));mark('trim-and-layout-set');await pause(600);
 await click(editor.getByRole('button',{name:'Add cue'}));
 await fill(editor.getByLabel('Caption 1',{exact:true}),'That was a close one.');
 await fill(editor.getByLabel('From',{exact:true}),'0');
 await fill(editor.getByLabel('To',{exact:true}),'8');
 await seek(editor.getByRole('slider',{name:'Playhead',exact:true}),5.1);
 const play=editor.getByRole('button',{name:'Play selection',exact:true});if(await play.isVisible())await click(play);
 mark('caption-live');await pause(1300);
 await click(editor.getByRole('button',{name:'Save',exact:true}));mark('edit-saved');await pause(800);
 await page.screenshot({path:path.join(root,'screenshots','live-workbench.png')});
 await click(editor.getByRole('button',{name:'Rights & review'}));mark('rights-opened');
 await editor.getByLabel('Game / underlying content rights').selectOption('authorized');await pause(300);
 await editor.getByLabel('Music rights').selectOption('licensed');
 await editor.getByLabel('Spoiler risk').selectOption('low');
 await fill(editor.getByLabel('Rights evidence / authorization basis'),'Original procedural motion and generated engine sound. Created for this demo.');
 await fill(editor.getByLabel('Review or rejection note'),'Reviewed this exact original-motion edit.');mark('rights-reviewed');await pause(700);
 await click(editor.getByRole('button',{name:'Approve & render',exact:true}));mark('render-requested');
 const download=editor.getByRole('link',{name:'Download',exact:true});await expect(download).toBeVisible({timeout:90000});mark('render-ready');
 await expect(editor.getByRole('status')).toHaveText('Your export is ready to download.');
 await click(editor.getByRole('button',{name:'Watch rendered output',exact:true}));
 const renderedVideo=editor.locator('video').filter({visible:true}).first();
 await expect.poll(()=>renderedVideo.evaluate(v=>v.readyState),{timeout:20000}).toBeGreaterThanOrEqual(2);
 await renderedVideo.evaluate(v=>{v.muted=true;return v.play()});mark('final-preview-playing');await pause(3200);
 await page.screenshot({path:path.join(root,'screenshots','final-preview.png')});
 const [file]=await Promise.all([page.waitForEvent('download'),click(download)]);if(await file.failure())throw new Error('Download failed');
 await file.saveAs(path.join(root,'export.mp4'));mark('download-saved');
 finalState=await json(await context.request.get(`${app}/api/candidates/${selected.id}`));
 if(finalState.status!=='rendered'||finalState.approved_revision!==finalState.edit_revision||finalState.approved_rights_revision!==finalState.rights_revision)throw new Error('Rendered output lacks matching edit and rights approval');
 await page.route('http://cliplane-export.local/export.mp4',route=>route.fulfill({path:path.join(root,'export.mp4'),contentType:'video/mp4'}));
 await page.goto('http://cliplane-export.local/export.mp4',{waitUntil:'domcontentloaded'});
 const actual=page.locator('video');await actual.waitFor();await actual.evaluate(v=>{v.muted=true;v.loop=true;return v.play()});mark('downloaded-export-playing');await pause(5000);
 await page.screenshot({path:path.join(root,'screenshots','downloaded-export.png')});mark('workflow-complete');
 await writeFile(path.join(root,'workflow-evidence.json'),JSON.stringify({isolatedWorkspace:true,imported:true,sourceStatus:sourceState.status,candidateStatus:finalState.status,editRevision:finalState.edit_revision,rightsRevision:finalState.rights_revision,approvedRevision:finalState.approved_revision,approvedRightsRevision:finalState.approved_rights_revision,sourcePlayback:{from:sourceFrom,to:sourceTo},editPlan:{startMs:finalState.edit_plan.startMs,endMs:finalState.edit_plan.endMs,layout:finalState.edit_plan.layout,caption:finalState.edit_plan.captions[0].text},requests},null,2));
}catch(error){mark('workflow-error',{message:String(error).split('\n')[0]});if(page)await page.screenshot({path:path.join(root,'screenshots','error.png')}).catch(()=>{});throw error;
}finally{await context.close();if(rawVideo)await rawVideo.saveAs(path.join(root,'raw.webm'));await browser.close();await writeFile(path.join(root,'action-timings.json'),JSON.stringify({startedAt:new Date(started).toISOString(),events},null,2));}
