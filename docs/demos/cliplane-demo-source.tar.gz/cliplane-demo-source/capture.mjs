/** Real Cliplane take: real import before camera, then edit/review/render/download. */
import { mkdir, readFile, symlink, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root=path.resolve(process.env.DEMO_DIR || path.dirname(fileURLToPath(import.meta.url)));
const project=path.resolve(process.env.CLIPLANE_ROOT || process.cwd());
const app=(process.env.APP_URL || 'http://localhost:3000').replace(/\/$/,'');
const source=path.resolve(process.env.DEMO_SOURCE || path.join(root,'nightdrift-original-motion.mp4'));
for(const sub of ['raw','tmp','screenshots','playwright-runtime'])await mkdir(path.join(root,sub),{recursive:true});
process.env.PLAYWRIGHT_LEGACY_SCREENSHOT ??= '1';
process.env.PLAYWRIGHT_BROWSERS_PATH=path.join(root,'playwright-runtime');
process.env.TMPDIR=path.join(root,'tmp');
const registry=JSON.parse(await readFile(path.join(project,'node_modules/playwright-core/browsers.json'),'utf8'));
const revision=registry.browsers.find(item=>item.name==='ffmpeg').revision;
const runtime=path.join(process.env.PLAYWRIGHT_BROWSERS_PATH,`ffmpeg-${revision}`);
await mkdir(runtime,{recursive:true});
try{await symlink(process.env.FFMPEG_BIN || '/usr/bin/ffmpeg',path.join(runtime,'ffmpeg-linux'));}catch(e){if(e.code!=='EEXIST')throw e;}
const { chromium,expect }=await import(pathToFileURL(path.join(project,'node_modules/@playwright/test/index.mjs')).href);
const stamp=Date.now().toString(36);
const game="Nightdrift · Original motion";
const title="Nightdrift / the close pass";
const events=[];const requests=[];const started=Date.now();
const mark=(name,extra={})=>{const e={name,wall:new Date().toISOString(),seconds:(Date.now()-started)/1000,...extra};events.push(e);console.log(JSON.stringify(e));};
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH || '/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage'],downloadsPath:path.join(root,'tmp')});
const context=await browser.newContext({viewport:{width:1600,height:900},recordVideo:{dir:path.join(root,'raw'),size:{width:1600,height:900},fps:30,showActions:{duration:220,cursor:'pointer',style:{title:'display:none',highlight:'outline:1px solid rgba(110,231,203,.6);outline-offset:3px;border-radius:5px;'}}},acceptDownloads:true,locale:'en-US',colorScheme:'light'});
let page;let rendered;let sourceRecord;let selected;let rawVideo;
const pause=ms=>page.waitForTimeout(ms);
async function click(locator){await locator.scrollIntoViewIfNeeded();await locator.hover();await pause(120);await locator.click();await pause(180);}
async function fill(locator,text){await locator.scrollIntoViewIfNeeded();await locator.click();if(await locator.getAttribute('type')==='number'){await locator.fill(text);}else{await locator.fill('');await locator.pressSequentially(text,{delay:14});}await pause(100);}
async function playSelection(){
 const button=page.getByRole('button',{name:'Play selection',exact:true});
 await click(button);
 await page.locator('video').evaluate(video=>{video.muted=true;});
}
async function json(response){if(!response.ok())throw new Error(`API request failed (${response.status()})`);return response.json();}
try{
 await json(await context.request.post(`${app}/api/auth/demo`,{data:{}}));
 // This is a real authorized upload and analysis, not seeded candidate data.
 // Keeping form entry outside the visible take lets the short cut start in media.
 const uploaded=await json(await context.request.post(`${app}/api/sources`,{multipart:{
  metadata:JSON.stringify({title,creator:'Cliplane demo',game,platform:'local',capturedAt:new Date().toISOString(),authorizationBasis:'I created this original procedural motion and sound. No game footage or third-party assets.',attestation:true,voiceAuthorized:true,embargoed:false}),
  file:{name:'nightdrift-original-motion.mp4',mimeType:'video/mp4',buffer:await readFile(source)},
 }}));
 requests.push({method:'POST',path:'/api/sources',status:201});
 mark('import-complete');
 for(let attempt=0;attempt<90;attempt++){
  sourceRecord=await json(await context.request.get(`${app}/api/sources/${uploaded.id}`));
  if(sourceRecord.status==='ready')break;
  if(sourceRecord.status==='failed')throw new Error('Actual source analysis failed');
  await new Promise(resolve=>setTimeout(resolve,1000));
 }
 if(sourceRecord.status!=='ready')throw new Error('Source analysis did not finish in90 seconds');
 const candidates=await json(await context.request.get(`${app}/api/candidates`));
 selected=candidates.find(candidate=>candidate.source_id===uploaded.id);
 if(!selected)throw new Error('Analysis produced no visible candidate');
 mark('analysis-ready');
 page=await context.newPage();rawVideo=page.video();
 page.on('response',response=>{
  const req=response.request();
  if(response.url().includes('/api/') && req.method()!=='GET')requests.push({method:req.method(),path:new URL(response.url()).pathname.replace(/[0-9a-f]{8}-[0-9a-f-]{27,}/gi,':id'),status:response.status()});
 });
 mark('navigate');
 await page.goto(`${app}/`,{waitUntil:'domcontentloaded'});
 await expect(page.getByRole('heading',{name:'From recording to remarkable.'})).toBeVisible();
 await page.getByLabel('Search moments').fill(game);
 const card=page.locator(".moment-card").filter({has:page.locator(`img[src="/api/candidates/${selected.id}/thumbnail"]`)});
 await expect(card).toBeVisible({timeout:20000});
 await card.scrollIntoViewIfNeeded();mark('candidate-visible');
 await pause(700);
 await click(card.locator('.moment-image'));
 await expect(page.getByRole('dialog')).toBeVisible();
 await expect.poll(()=>page.locator('video').evaluate(video=>video.readyState),{timeout:20000}).toBeGreaterThanOrEqual(2);
 await playSelection();
 mark('source-playing');
 await pause(2800);
 await fill(page.getByLabel('Start (seconds)'),'5');
 await fill(page.getByLabel('End (seconds)'),'13');
 await fill(page.getByLabel('Clip title'),'That was a close one');
 await click(page.getByRole('button',{name:'Vertical crop'}));
 await playSelection();
 mark('trim-and-layout-set');
 await pause(1000);
 await click(page.getByRole('button',{name:'Add cue'}));
 await fill(page.getByLabel('Caption 1',{exact:true}),'That was a close one.');
 mark('caption-and-mute-set');
 await pause(900);
 await click(page.getByRole('button',{name:'Rights & review'}));
 await page.getByLabel('Game / underlying content rights').selectOption('authorized');
 await pause(200);
 await page.getByLabel('Music rights').selectOption('licensed');
 await page.getByLabel('Spoiler risk').selectOption('low');
 await fill(page.getByLabel('Rights evidence / authorization basis'),'Original procedural motion and engine sound. Created for this demo.');
 await fill(page.getByLabel('Review or rejection note'),'Reviewed this exact original-motion edit.');
 mark('rights-reviewed');
 await pause(900);
 await click(page.getByRole('button',{name:'Approve & render',exact:true}));
 mark('render-requested');
 const download=page.getByRole('link',{name:'Download',exact:true});
 await expect(download).toBeVisible({timeout:90000});mark('render-ready');
 await click(page.getByRole('button',{name:'Watch rendered output'}));
 await expect.poll(()=>page.locator('video').evaluate(video=>video.readyState),{timeout:20000}).toBeGreaterThanOrEqual(2);
 await page.locator('video').scrollIntoViewIfNeeded();
 await page.locator('video').evaluate(video=>{video.muted=true;return video.play();});
 mark('final-preview-playing');mark('rendered-preview-playing');
 await pause(4200);
 await page.screenshot({path:path.join(root,'screenshots','final-preview.png')});mark('final-screenshot');
 const [downloaded]=await Promise.all([page.waitForEvent('download'),click(download)]);
 if(await downloaded.failure())throw new Error(await downloaded.failure());
 await downloaded.saveAs(path.join(root,'export.mp4'));mark('download-saved');
 rendered=await json(await context.request.get(`${app}/api/candidates/${selected.id}`));
 await pause(800);
 // Show the actual downloaded bytes playing in Chromium, not a mock-up or still.
 await page.route('http://cliplane-export.local/export.mp4',route=>route.fulfill({path:path.join(root,'export.mp4'),contentType:'video/mp4'}));
 await page.goto('http://cliplane-export.local/export.mp4',{waitUntil:'domcontentloaded'});
 const actual=page.locator('video');await actual.waitFor();
 await actual.evaluate(video=>{video.muted=true;video.loop=true;return video.play();});
 mark('downloaded-export-playing');await pause(5000);
 await page.screenshot({path:path.join(root,'screenshots','downloaded-export.png')});
 mark('workflow-complete');
 await writeFile(path.join(root,'workflow-evidence.json'),JSON.stringify({imported:true,sourceStatus:sourceRecord.status,candidateStatus:rendered.status,editRevision:rendered.edit_revision,editPlan:{startMs:rendered.edit_plan.startMs,endMs:rendered.edit_plan.endMs,layout:rendered.edit_plan.layout,caption:rendered.edit_plan.captions[0].text},requests},null,2));
}catch(error){
 mark('workflow-error',{message:String(error)});
 if(page)await page.screenshot({path:path.join(root,'screenshots','error.png')}).catch(()=>{});
 throw error;
}finally{
 await context.close();
 if(rawVideo)await rawVideo.saveAs(path.join(root,'raw.webm'));
 await browser.close();
 await writeFile(path.join(root,'action-timings.json'),JSON.stringify({startedAt:new Date(started).toISOString(),events},null,2));
}
