"""Probe, fully decode and hash media; report MP4 fast-start box order."""
import hashlib, json, struct, subprocess, sys
from pathlib import Path


def fast_start(path):
    if path.suffix.lower() != ".mp4":
        return None
    boxes = {}
    with path.open("rb") as source:
        offset = 0
        total = path.stat().st_size
        while offset + 8 <= total:
            source.seek(offset)
            size, kind = struct.unpack(">I4s", source.read(8))
            if size == 1:
                size = struct.unpack(">Q", source.read(8))[0]
            elif size == 0:
                size = total - offset
            if size < 8 or offset + size > total:
                raise ValueError("Invalid MP4 box size")
            boxes.setdefault(kind, offset)
            offset += size
    return b"moov" in boxes and b"mdat" in boxes and boxes[b"moov"] < boxes[b"mdat"]


for value in sys.argv[1:]:
    path=Path(value)
    data=json.loads(subprocess.check_output(["ffprobe","-v","error","-show_entries","format=duration:stream=codec_type,codec_name,width,height,pix_fmt,avg_frame_rate","-of","json",str(path)]))
    subprocess.run(["ffmpeg","-v","error","-i",str(path),"-f","null","-"],check=True)
    print(json.dumps({"file":path.name,"bytes":path.stat().st_size,"sha256":hashlib.sha256(path.read_bytes()).hexdigest(),"probe":data,"fullDecode":"passed","fastStart":fast_start(path)}))
