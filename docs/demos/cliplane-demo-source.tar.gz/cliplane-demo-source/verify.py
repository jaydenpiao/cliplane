"""Read back and decode the deliverables; retain compact verification evidence."""
from pathlib import Path
import hashlib,json,os,struct,subprocess

ROOT=Path(os.environ.get('DEMO_DIR', str(Path(os.environ.get('CLIPLANE_ROOT', Path.cwd()))/'work'/'demo-capture'))).resolve()
FFMPEG=os.environ.get('FFMPEG_BIN','ffmpeg')
FFPROBE=os.environ.get('FFPROBE_BIN','ffprobe')
results={}
for name in ('cliplane-demo-edited.mp4','cliplane-rendered-clip.mp4','cliplane-workflow-raw.webm'):
    path=ROOT/name
    metadata=json.loads(subprocess.check_output([FFPROBE,'-v','error','-show_format','-show_streams','-of','json',str(path)]))
    (ROOT/(name+'.ffprobe.json')).write_text(json.dumps(metadata,indent=2))
    video=[s for s in metadata['streams'] if s['codec_type']=='video']
    audio=[s for s in metadata['streams'] if s['codec_type']=='audio']
    assert len(video)==1 and not audio,name
    v=video[0]
    assert v['avg_frame_rate']=='30/1' and v['pix_fmt']=='yuv420p',name
    duration=float(metadata['format']['duration'])
    if name=='cliplane-demo-edited.mp4':
        assert v['codec_name']=='h264' and (v['width'],v['height'])==(1920,1080)
        assert v['sample_aspect_ratio']=='1:1' and 30<=duration<=60
    elif name=='cliplane-rendered-clip.mp4':
        assert v['codec_name']=='h264' and (v['width'],v['height'])==(720,1280)
        assert abs(duration-7)<.034
    else:
        assert (v['width'],v['height'])==(1440,900) and v['codec_name']=='vp9'
    subprocess.run([FFMPEG,'-v','error','-i',str(path),'-f','null','-'],check=True,stdout=subprocess.DEVNULL)
    result={'durationSeconds':duration,'bytes':path.stat().st_size,'codec':v['codec_name'],'width':v['width'],'height':v['height'],'fps':v['avg_frame_rate'],'pixelFormat':v['pix_fmt'],'audioStreams':len(audio),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'fullDecode':'passed'}
    if path.suffix=='.mp4':
        atoms=[]
        with path.open('rb') as f:
            while header:=f.read(8):
                size,kind=struct.unpack('>I4s',header)
                if size==1:
                    size=struct.unpack('>Q',f.read(8))[0];skip=size-16
                elif size==0:break
                else:skip=size-8
                atoms.append(kind.decode('ascii'));f.seek(skip,1)
        assert atoms.index('moov')<atoms.index('mdat')
        result['fastStart']=True
    results[name]=result
if (ROOT/'workflow-evidence.json').exists():
    evidence=json.loads((ROOT/'workflow-evidence.json').read_text())
    assert evidence['candidateStatus']=='rendered'
    assert evidence['sourceStatus']=='ready'
    assert evidence['pageErrorCount']==0
    plan=evidence['editPlan']
    assert plan['startMs']==12000 and plan['endMs']==19000 and plan['muteAudio']
    assert plan['caption']=='One recording. Your next story.'
    results['workflow']={'sourceStatus':'ready','candidateStatus':'rendered','browserPageErrors':0,'editMilliseconds':7000,'captions':1,'audioMuted':True}
(ROOT/'verification.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
