import hashlib, json, subprocess, sys
from pathlib import Path
for value in sys.argv[1:]:
    path=Path(value)
    data=json.loads(subprocess.check_output(["ffprobe","-v","error","-show_entries","format=duration:stream=codec_type,codec_name,width,height,pix_fmt,avg_frame_rate","-of","json",str(path)]))
    subprocess.run(["ffmpeg","-v","error","-i",str(path),"-f","null","-"],check=True)
    print(json.dumps({"file":path.name,"sha256":hashlib.sha256(path.read_bytes()).hexdigest(),"probe":data,"fullDecode":"passed"}))
